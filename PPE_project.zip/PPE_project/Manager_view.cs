﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing.Drawing2D;

namespace PPE_project
{
    public partial class Manager_view : Form
    {
        public Manager_view()
        {
            InitializeComponent();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {
            Panel panel1 = (Panel)sender;
            int radius = 20;


            
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void Manager_view_Load(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            Alarm alarm = new Alarm();
            alarm.ShowDialog();
        }
    }
}
