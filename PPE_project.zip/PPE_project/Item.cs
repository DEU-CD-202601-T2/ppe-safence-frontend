﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PPE_project
{
    public partial class Item : UserControl
    {
        public Item()
        {
            InitializeComponent();
        }

        public void SetItem(string stype, string stime, string szone, string sid, Image sphoto)
        {
            type.Text = stype;
            date.Text = stime;
            zone.Text = szone;
            Id.Text = sid;
            photo.Image = sphoto;

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
