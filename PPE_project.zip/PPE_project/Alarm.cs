﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PPE_project
{
    public partial class Alarm : Form
    {
        public Alarm()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void AddItemlist()
        {
            for (int i = 0; i < 5; i++)
            {
                Item item = new Item();
                item.SetItem("안전화 미착용", "2024-06-01 12:00:00", "Zone A", "ID12345", null);
                flowLayoutPanel1.Controls.Add(item);
            }
        }
    }
}
